## Imports
import pygame;
from pygame.locals import FULLSCREEN, DOUBLEBUF;
import os;
import sys;
from screeninfo import get_monitors;
import random;
import socket;
import threading;
import json;
import time;


## Top Level Functions

def draw(): #draws the screen every frame
    drawNormal(assets["background"], 0, 0, 1920, 1080);
    for i in range(len(server.players)):
        if i == 0:
            x, y = 960-150, 700;
        else: 
            x, y = 960-150, 100;
        drawHand(eval("server.players["+str(i)+"].cards"), True, x, y, 2);
    # drawOpen(deck, 1.4);
    
    pygame.display.flip();
    clock.tick(30);
    
def setup(): # initializes all required components
    global rx, ry, screen, clock;
    for m in get_monitors():
        if m.is_primary:
            realX = m.width;
            realY = m.height;
            
    nativeX, nativeY = 1920, 1080;
    realX, realY = nativeX, nativeY; # to be removed
    rx, ry = realX/nativeX, realY/nativeY;
    pygame.init();
    screen = pygame.display.set_mode()
    # flags = FULLSCREEN | DOUBLEBUF;
    # screen = pygame.display.set_mode((realX, realY), flags, 16);
    screen = pygame.display.set_mode((realX, realY));
    clock = pygame.time.Clock();

def functions(): # creates all non top level functions
    global drawRotated, drawNormal, drawOpen, drawHand, serverround, start_server, connect, receive, send, startGame, tryTakeCard;

    # graphics
    def drawRotated(img, x = 0, y = 0, angle = 180, mx = 1, my = 1, stretch = 1, surface = screen):
        x, y = round(x*rx), round(y*ry);
        if angle == "flip":
            img = pygame.transform.flip(img, False, True);
        elif angle == 180:
            img = pygame.transform.flip(img, True, True);
        else:
            img = pygame.transform.scale(img, (mx, my));
            img = pygame.transform.rotate(img, -1*angle);
        mx, my = mx*rx, my*ry;
        img = pygame.transform.scale(img, (mx*stretch, my/stretch));
        surface.blit(img, (x, y));

    def drawNormal(img, x = 0, y = 0, mx = 1, my = 1, surface = screen):
        x, y, mx, my = round(x*rx), round(y*ry), mx*rx, my*ry;
        img = pygame.transform.scale(img, (mx, my));
        surface.blit(img, (x, y));

    def drawOpen(cards, size = 1):
        i = 0;
        for card in cards:
            columns = 15;
            row = i // columns;
            column = i - row*columns;
            card.draw(column*90*size, row*140*size, size);
            i+=1;

    def drawHand(cards, show, x, y, size = 1):
        width = 300 * size;
        i = 1;
        for card in cards:
            angle = ((i-0.5)/len(cards)-0.5) * 2 * 20;
            posX = x - width/2 + i/len(cards) * width;
            posY = y + (abs((i-0.5)/len(cards)-0.5)*10)**2.25;
            subSize = size + (abs((i-0.5)/len(cards)-0.5)*2**2.25*0.1);
            if show:
                card.drawRotated(posX, posY, subSize, angle);
            else:
                drawRotated(assets["cardback"], posX, posY, angle, subSize*82, subSize*128, 1, screen);
            i += 1;

    # round repeating loop
    def serverround():
        pass;
    
    # connection
    def start_server():
        global server_socket;
        host = 'localhost';
        port = 12344;

        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM);
        server_socket.bind((host, port));
        server_socket.listen(4);

    def connect():
        conn, addr = server_socket.accept()
        client_thread = threading.Thread(target=handleClient, args=(conn, addr))
        client_thread.start();
    
    def handleClient(conn, addr):
        print('Connected by', addr)
        message = Message("server", "setName", str(len(server.players)+1));
        server.players.append(Player(5));
        send(conn, message);
        while True:
            try:
                message = receive(conn, addr);
                messageFunctions[message.type](message.sender, message.content);
            except Exception as e:
                print(e);
                break;
        conn.close()
    
    def receive(conn, addr):
        data = conn.recv(2048)
        if not data:
            raise Exception("disconnected", addr)
        message = json.loads(data.decode('utf-8'));
        return Message(message['sender'], message['type'], message['content']);
    
    def send(conn, message):
        message = {
            'sender': message.sender,
            'type': message.type,
            'content': message.content
        }

        message = json.dumps(message);
        conn.sendall(message.encode('utf-8'));
        
    def send(conn, message):
        message = {
            'sender': message.sender,
            'type': message.type,
            'content': message.content
        }

        message = json.dumps(message);
        conn.sendall(message.encode('utf-8'));
    
    # server code
    def startGame():
        global server;
        server = Server();
    
    # player interactions
    def tryTakeCard(sender, content):
        server.players[int(sender)-1].takeCard(int(content));
        

def classes(): # creates all classes
    global Card, Player, Server, Message;

    class Card():
        def __init__(self, color, value):
            self.color = color;
            self.value = value;

        def drawCorners(self, x, y, size, surface = screen):
            border = 8 * size;
            width, height = size * 82, size * 128;
            symbolSize = 20*size;
            drawNormal(assets[self.value], x+border, y+border, symbolSize, symbolSize, surface);
            drawRotated(assets[self.value], x+width-symbolSize-border, y+height-symbolSize-border, 180, symbolSize, symbolSize, 1, surface);
        
        def drawMiddle(self, x, y, size, surface = screen):
            width, height = size * 82, size * 128;
            symbolSize = 45*size;
            if self.value == "plus4":
                drawNormal(assets["plus4_big"], x+width/2-symbolSize/2, y+height/2-symbolSize/2, symbolSize, symbolSize, surface);
            elif self.value == "colors":
                symbolHeight, symbolWidth = 104*size, 72*size;
                drawNormal(assets["colors_big"], x+width/2-symbolWidth/2, y+height/2-symbolHeight/2, symbolWidth, symbolHeight, surface);
            else:
                drawNormal(assets[self.value], x+width/2-symbolSize/2, y+height/2-symbolSize/2, symbolSize, symbolSize, surface);

        def draw(self, x = 0, y = 0, size = 1, surface = screen):
            w, h = size * 82, size * 128;
            drawNormal(assets[self.color], x, y, w, h, surface);
            drawNormal(assets["card_extra"], x, y, w, h, surface);
            self.drawCorners(x, y, size, surface);
            self.drawMiddle(x, y, size, surface);

        def drawRotated(self, x=0, y=0, size=1, angle=0, surface=screen):
            w, h = size * 82, size * 128;
            
            cardSurface = pygame.Surface((size * 82* 1.33, size * 128* 1.33), pygame.SRCALPHA)

            self.draw(0, 0, size, cardSurface)

            drawRotated(cardSurface, x, y, angle, w, h, 1, surface);

    class Player():
        def __init__(self, cards = []):
            if isinstance(cards, list):
                self.cards = cards;
            elif isinstance(cards, int):
                self.cards = [];
                self.drawCards(cards, deck);
        
        def drawCards(self, amount, stack): # actually draw cards to the players cards (not graphically)
            for i in range(amount):
                card = random.choice(stack);
                self.cards.append(card);
                stack.remove(card);

    class Server():
        def __init__(self):
            self.players = [];
            self.turn = 0;
            
    class Message():
        def __init__(self, sender, type, content):
                self.sender = sender;
                self.type = type;
                self.content = content;
          
def preload(): # loads variables before starting the script
    global assets, colors, values, messageFunctions, deck, player1;
    root = os.path.dirname(os.path.abspath(__file__));
    images = os.listdir(f"{root}/assets");
    colors = ["red", "green", "blue", "yellow"];
    values = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "switch", "skip", "plus2", "colors", "plus4"];
    specialValues = ["colors", "plus4"];
    messageFunctions = {
        "takeCard": tryTakeCard
        };
    deck = [];
    for color in colors:
        for value in values:
            if value in specialValues:
                color = "black";
            deck.append(Card(color, value));
    assets = {};
    for image in images:
        if ".png" in image:
            assets[os.path.split(image)[1].replace(".png", "")] = pygame.image.load(os.path.join(f"{root}/assets", image)).convert_alpha();

  
def main(): # main function
    game = True;
    gameRound = True;
    connect();
    while game:
        for event in pygame.event.get():
            if event.type == pygame.QUIT: # ALT+F4/X-Button handling
                game = False;
            elif event.type == pygame.KEYDOWN: # Keyboard handling
                print(f"Key {event.key} pressed");
            elif event.type == pygame.MOUSEBUTTONDOWN: # Mouse handling
                print(f"Mouse button {event.button} pressed at {event.pos}");
        
        draw();
    pygame.quit();
    sys.exit();


## Script
if __name__ == '__main__':
    setup();
    classes();
    functions();
    preload();
    startGame();
    start_server();
    main();