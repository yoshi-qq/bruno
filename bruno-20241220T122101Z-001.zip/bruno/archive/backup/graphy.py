import pygame, os, random, sys, time, math, inspect;
from screeninfo import get_monitors;
from pygame.locals import HWSURFACE, DOUBLEBUF, FULLSCREEN;


screen = None;
clickEvent = False;
sprites = {};



def preload(file, nativeRes = (1920, 1080), scale = 1, windowRes = False):
    global root, displayResolution, nativeResolution, middle, rx, ry, xMultiplier, yMultiplier;
    root = os.path.dirname(os.path.abspath(file));
    nativeResolution = nativeRes;
    displayResolution = nativeResolution;
    middle = (displayResolution[0]/2, displayResolution[1]/2);
    if windowRes == False:
        for monitor in get_monitors():
            if monitor.is_primary:
                displayResolution = (monitor.width*scale, monitor.height*scale);
                break;
    else:
        displayResolution = windowRes;
    xMultiplier, yMultiplier = displayResolution[0]/nativeResolution[0], displayResolution[1]/nativeResolution[1];
    if singleSize:
        rx, ry = xMultiplier, yMultiplier;
    else:
        rx, ry = 1, 1;
    

def init(file = __file__, fullscreen = False, singleSizeOn = False, windowName = "GRAPHY!", spriteFolder = "assets", spriteExtension = ".png", scale = 1, nativeRes = (1920, 1080), windowIcon = "icon", windowRes = False):
    global sprites, screen, realScreen, renders, clock, nativeResolution, singleSize;
    nativeResolution = nativeRes;
    singleSize = singleSizeOn;
    preload(file, nativeResolution, scale, windowRes);
    pygame.init();
    pygame.display.set_caption(windowName);
    if fullscreen:
        flags = HWSURFACE | DOUBLEBUF | FULLSCREEN;
    else:
        flags = HWSURFACE | DOUBLEBUF;
    if not singleSize:
        screen = pygame.surface.Surface((nativeResolution[0], nativeResolution[1]), flags);
        realScreen = pygame.display.set_mode((displayResolution[0], displayResolution[1]), flags);
    else:
        screen = pygame.display.set_mode((displayResolution[0], displayResolution[1]), flags);
    renders = [];
    spriteRoot = os.path.join(root, spriteFolder);
    sprites = {};
    scanDirectory(spriteRoot, spriteExtension);
    try:
        pygame.display.set_icon(sprites[windowIcon][0]);
    except: pass;
    clock = pygame.time.Clock();

def scanDirectory(directory, extension = ".png", extra = ""):
    for file in os.listdir(directory):
        if os.path.isdir(os.path.join(directory, file)):
            scanDirectory(os.path.join(directory, file), extension, f"{extra}/{file}");
        elif file.endswith(extension):
            image = pygame.image.load(os.path.join(directory, file));
            if image.get_alpha() is None:
                image = image.convert();
                scaler = 4;
                image = pygame.transform.scale(image, (round(image.get_width()*rx*scaler), round(image.get_height()*ry*scaler)));
                sprites[file.replace(extension, "")] = (image, extra, False);
            else:
                image = image.convert_alpha();
                scaler = 4;
                image = pygame.transform.scale(image, (round(image.get_width()*rx*scaler), round(image.get_height()*ry*scaler)));
                sprites[file.replace(extension, "")] = (image, extra, True);

def drawNormal(surface, img, x = 0, y = 0, width = 1, height = 1, middle = False):
    global sprites;
    x, y, width, height = round(x*rx), round(y*ry), width*rx, height*ry;
    if abs(img.get_height() - height) > 1 or abs(img.get_width() - width) > 1:
        img = pygame.transform.scale(img, (width, height));
    topleft = (x, y);
    if middle:
        topleft = (x - img.get_width()/2, y - img.get_height()/2);
    surface.blit(img, topleft);

def drawRotated(surface, img, x = 0, y = 0, angle = 180, width = 1, height = 1, stretch = 1, middle = False):
    width, height = width*rx, height*ry;
    if abs(img.get_height() - height/stretch) > 1 or abs(img.get_width() - width*stretch) > 1:
        img = pygame.transform.scale(img, (width*stretch, height/stretch));
    if angle == 0:
        drawNormal(surface, img, x, y, width, height, middle);
        return;
    elif angle == "flip":
        img = pygame.transform.flip(img, False, True);
    elif angle == 180:
        img = pygame.transform.flip(img, True, True);
    else:
        if abs(img.get_height() - height) > 1 or abs(img.get_width() - width) > 1:
            img = pygame.transform.scale(img, (width, height));
        center = img.get_rect().center;
        img = pygame.transform.rotate(img, -1*angle);
        rotated_rect = img.get_rect();
        rotated_rect.center = center;
        offset_x = rotated_rect.x - surface.get_rect().x
        offset_y = rotated_rect.y - surface.get_rect().y
        x += offset_x*0.75;
        y += offset_y*0.75;
    x, y = round(x*rx), round(y*ry);
    topleft = (x, y);
    if middle:
        topleft = (x - img.get_width()/2, y - img.get_height()/2);
    surface.blit(img, topleft);

def getMouse():
    return (pygame.mouse.get_pos()[0]/xMultiplier, pygame.mouse.get_pos()[1]/yMultiplier);

def click():
    global clickEvent;
    clickEvent = True;

def preDraw():
    pass;

def postDraw():
    pass;

def draw():
    global clickEvent, renders;
    screen.fill((50, 50, 50));
    renders.sort(key = lambda render: render.priority + render.priorityOffset);
    preDraw();
    hoverable = True;
    for render in renders[::-1]:
        if render.enabled and isinstance(render, RenderButton):
                if hoverable and pointInRect(getMouse(), (render.x, render.y, render.width, render.height), render.angle):
                    render.hover(True);
                    if clickEvent and render.clickAction != False:
                        render.clickAction(*render.arguments);
                    hoverable = False;
                else:
                    render.hover(False);
    i = 0;
    for render in renders:
        if render.enabled:
            render.draw();  
        if render.temporary:
            renders.pop(i);
        i+=1;
    clicked = not clickEvent;
    clickEvent = False;
    postDraw();
    if not singleSize:
        realScreen.blit(pygame.transform.scale(screen, (displayResolution[0], displayResolution[1])), (0, 0));
    pygame.display.flip();
    clock.tick(30);
    return clicked;

def renderThis(renderObject):
    pass;

#future use
def rectOverlap(rect1, rect2):
    l1 = Point(rect1[0],rect1[1]);
    r1 = Point(rect1[0]+rect1[2], rect1[1]+rect1[3]);
    l2 = Point(rect2[0],rect2[1]);
    r2 = Point(rect2[0]+rect2[2], rect2[1]+rect2[3]);
    
    # if rectangle has area 0, no overlap
    if l1.x == r1.x or l1.y == r1.y or r2.x == l2.x or l2.y == r2.y:
        return False;
     
    # If one rectangle is on left side of other
    if l1.x > r2.x or l2.x > r1.x:
        return False;
 
    # If one rectangle is above other
    if r1.y < l2.y or r2.y < l1.y:
        return False;
 
    return True; 

def markthis(size = 10):
    x, y = pygame.mouse.get_pos();
    RenderImage(imageName = "mark", x = x/rx, y = y/ry, surface = screen, priority=10, width = size, height = size, middle = True);

def rotate_point_around_center(point, center, angle_degrees):
    """Rotate a point around another point by a given angle in degrees, counter-clockwise."""
    angle_radians = math.radians(-angle_degrees)  # Negative for counter-clockwise rotation
    px, py = point
    cx, cy = center
    
    # Translate point back to origin:
    px -= cx
    py -= cy
    
    # Rotate point
    xnew = px * math.cos(angle_radians) - py * math.sin(angle_radians)
    ynew = px * math.sin(angle_radians) + py * math.cos(angle_radians)
    
    # Translate point back:
    px = xnew + cx
    py = ynew + cy
    return px, py

def pointInRect(mouse_pos, rect, angle_degrees = 0):
    """Check if the mouse cursor is within a rotated rectangle."""
    rect_x, rect_y, rect_w, rect_h = rect
    center = (rect_x + rect_w / 2, rect_y + rect_h / 2)
    
    # Rotate the mouse position in the opposite direction of the rectangle's rotation
    unrotated_mouse_pos = rotate_point_around_center(mouse_pos, center, angle_degrees)
    
    # Check if the unrotated mouse position is within the bounds of the original rectangle
    return (rect_x <= unrotated_mouse_pos[0] <= rect_x + rect_w and
            rect_y <= unrotated_mouse_pos[1] <= rect_y + rect_h)


class Sprite(pygame.sprite.Sprite):
    def __init__(self, image, position):
        super().__init__();
        self.image = image;
        self.rect = self.image.get_rect(topleft=position);

#future use
class Point:
    def __init__(self, x, y):
        self.x = x;
        self.y = y;
           
class RenderObject():
    def __init__(self, surface = screen, temporary = False, enabled = True, x = 0, y = 0, width = 10, height = 10, priority = 2, angle = 0, stretch = 1):
        self.enabled = enabled;
        self.temporary = temporary;
        self.x = x;
        self.y = y;
        self.width = width;
        self.height = height;
        self.priority = priority;
        self.priorityOffset = 0;
        self.angle = angle;
        self.stretch = stretch;
        self.surface = surface;
        
    def show(self):
        self.enabled = True;
        
    def hide(self):
        self.enabled = False;
        
    def remove(self):
        global renders;
        renders.remove(self);
        
class RenderImage(RenderObject):
    def __init__(self, strName = "image", surface = screen, temporary = False, enabled = True, imageName = "image", x = 0, xOffset = 0, y = 0, yOffset = 0, width = 10, height = 10, middle = False, priority = 2, angle = 0, stretch = 1, mapPosition = (None, None), gen = True):
        self.strName = strName;
        self.name = imageName;
        self.imageName = imageName;
        self.xOffset = xOffset;
        self.yOffset = yOffset;
        self.middle = middle;
        self.sizeMulti = 1;
        self.mapPosition = mapPosition;
        try:
            self.image = sprites[imageName][0];
        except KeyError:
            self.image = imageName;
        super().__init__(surface = surface, temporary = temporary, enabled = enabled, x = x, y = y, width = width, height = height, priority = priority, angle = angle, stretch = stretch);
        if type(self) is RenderImage and gen:
            renders.append(self);
    
    def offset(self, x: float = None, y: float = None, size: float = None, priority = None):
        if x is not None:
            self.xOffset = x;
        if y is not None:
            self.yOffset = y;
        if size is not None:
            self.sizeMulti = size;
        if priority is not None:
            self.priorityOffset = priority;
    
    def update(self):
        try:
            self.image = sprites[self.image][0];
        except KeyError:
            self.image = self.image;
    def draw(self):
        drawRotated(surface = self.surface, img = self.image, x = self.x + self.xOffset, y = self.y + self.yOffset, angle = self.angle, width = self.width * self.sizeMulti, height = self.height * self.sizeMulti, stretch = self.stretch, middle = self.middle);

    def changeImage(self, image):
        try:
            self.image = sprites[image][0];
        except KeyError:
            self.image = image;
    
class RenderButton(RenderImage):
    def __init__(self, imageName: str, strName = "button", clickAction = False, hoverAction = False, unHoverAction = False, arguments: tuple = (), hoverArguments: tuple = (), unHoverArguments: tuple = (), surface = screen, temporary = False, enabled = True, hoverImageName = False, x = 0, xOffset = 0, y = 0, yOffset = 0, width = 10, height = 10, priority = 2, angle = 0, stretch = 1, gen = True):
        if isinstance(clickAction, str): # define click action
            clickAction = eval(clickAction);  
        self.clickAction = clickAction;
        self.arguments = arguments;
        if isinstance(hoverAction, str): # define hover action
            hoverAction = eval(hoverAction); 
        self.hoverAction = hoverAction;
        self.hoverArguments = hoverArguments;
        if isinstance(unHoverAction, str): # define unhover action
            unHoverAction = eval(unHoverAction);  
        self.unHoverAction = unHoverAction;
        self.unHoverArguments = unHoverArguments;
        
        # define images
        self.hoverImageName = hoverImageName;
        
        self.hovered = False;
        
        super().__init__(strName = strName, surface = surface, temporary = temporary, enabled = enabled, imageName = imageName, x = x, xOffset = xOffset, y = y, yOffset = yOffset, width = width, height = height, priority = priority, angle = angle, stretch = stretch, gen = gen);
        renders.append(self);
    
    def hover(self, hover = False):
        if hover:
            if True:
                self.hovered = True;
                if self.hoverImageName != False:
                    self.image = sprites[self.hoverImageName][0];
                if self.hoverAction != False:
                    self.hoverAction(*self.hoverArguments);
        elif self.hovered:
            self.hovered = False;
            if self.hoverImageName != False:
                self.image = sprites[self.imageName][0];
            if self.unHoverAction != False:
                self.unHoverAction(*self.unHoverArguments);
    
    def draw(self):
        return super().draw();
    
class RenderText(RenderObject):
    def __init__(self, surface: pygame.surface = screen, enabled = True, x: int = 0, y: int = 0, xOffset: int = 0, yOffset: int = 0, text: str = "example", font: pygame.font = None, size: int = 30, color: tuple = (0, 0, 0), temporary = False, angle = 0, stretch = 1, middle = False, priority: float = 2, gen: bool = True):
        self.font = pygame.font.Font(font, size);
        self.text = text;
        self.middle = middle;
        self.xOffset = xOffset;
        self.yOffset = yOffset;
        self.sizeMulti = 1;
        self.renderSurface = self.font.render(text, False, color);
        height = self.renderSurface.get_height();
        width = self.renderSurface.get_width();
        super().__init__(surface = surface, temporary = temporary, enabled = enabled, x = x, y = y, width = width, height = height, priority = priority, angle = angle, stretch = stretch);
        if type(self) is RenderText and gen:
                renders.append(self);
    
    def draw(self):
        drawRotated(surface = self.surface, img = self.renderSurface, x = self.x + self.xOffset, y = self.y + self.yOffset, angle = self.angle, width = self.width * self.sizeMulti, height = self.height * self.sizeMulti, stretch = self.stretch, middle = self.middle);


class GameObject():
    def __init__(self, strName = "image", x = 0, y = 0, renderObject = None, enabled = True, angle = 0, priority = 2):
        global renders;
        self.strName = strName;
        self.x = x;
        self.y = y;
        self.angle = angle;
        self.enabled = enabled;
        self.priority = priority;
        renderObject.x = self.x;
        renderObject.y = self.y;
        renderObject.angle = self.angle;
        renderObject.strName = self.strName;
        renderObject.priority = self.priority;
        renderObject.enabled = self.enabled;
        self.renderObject = renderObject;
        renders.append(self.renderObject);
        
    def update(self):
        self.renderObject.x = self.x;
        self.renderObject.y = self.y;
        self.renderObject.angle = self.angle;
        self.renderObject.enabled = self.enabled;
        self.renderObject.priority = self.priority;

    
    
def example():    
    init();
    example = GameObject(0, 0, RenderImage(screen, False, True, random.choice(list(sprites.keys())), 0, 0, 100, 100));
    running = True;
    while running:
        draw();
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False;
                
        keys = pygame.key.get_pressed();
        if keys[pygame.K_RIGHT]:
            example.x += 5;
            example.update();
        if keys[pygame.K_LEFT]:
            example.x -= 5;
            example.update();
        if keys[pygame.K_UP]:
            example.y -= 5;
            example.update();
        if keys[pygame.K_DOWN]:
            example.y += 5;
            example.update();
        if keys[pygame.K_SPACE]:
            example.changeImage(random.choice(list(sprites.keys())));
    
    
if __name__ == "__main__":
    example();