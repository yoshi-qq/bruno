from networking import *;

if __name__ == '__main__':
    client = Client(input("ip"), 54321, 1024, "pickle", True); # Starten eines Test-Clients
