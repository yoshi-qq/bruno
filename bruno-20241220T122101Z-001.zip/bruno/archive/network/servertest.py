from networking import *;

if __name__ == '__main__': # Nur bei direktem Ausführen des Skripts verwendet
    server = Server(input("ip"), 54321, 1024, "pickle", 4, True); # Starten eines Test-Servers
